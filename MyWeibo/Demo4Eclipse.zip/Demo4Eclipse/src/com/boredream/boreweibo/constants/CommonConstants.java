package com.boredream.boreweibo.constants;

public interface CommonConstants {

	String SP_NAME = "sp_config";
	boolean isShowLog = true;
	boolean isSaveLog2File = false;

}
