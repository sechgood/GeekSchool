package com.boredream.boreweibo.entity;

import java.io.Serializable;

public class BaseEntity implements Serializable {

}
