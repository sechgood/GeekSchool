/** Automatically generated file. DO NOT MODIFY */
package com.boredream.boreweibo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}