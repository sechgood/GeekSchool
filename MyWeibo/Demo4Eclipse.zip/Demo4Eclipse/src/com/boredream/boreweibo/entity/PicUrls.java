package com.boredream.boreweibo.entity;

/*sub class*/
public class PicUrls extends BaseBean {
	private String thumbnail_pic;
	private String original_pic;

	public String getThumbnail_pic() {
		return thumbnail_pic;
	}

	public void setThumbnail_pic(String thumbnail_pic) {
		this.thumbnail_pic = thumbnail_pic;
	}

	public String getOriginal_pic() {
		return original_pic;
	}

	public void setOriginal_pic(String original_pic) {
		this.original_pic = original_pic;
	}

}