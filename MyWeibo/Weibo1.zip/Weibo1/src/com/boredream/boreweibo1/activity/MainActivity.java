package com.boredream.boreweibo1.activity;

import android.app.Activity;
import android.os.Bundle;

import com.boredream.boreweibo1.R;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}
