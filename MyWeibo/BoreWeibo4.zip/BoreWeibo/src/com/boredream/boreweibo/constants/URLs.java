package com.boredream.boreweibo.constants;

public interface URLs {

	String BASE_URL = "https://api.weibo.com/2/";
	
	String statusesHome_timeline = BASE_URL + "statuses/home_timeline.json";
	
}
